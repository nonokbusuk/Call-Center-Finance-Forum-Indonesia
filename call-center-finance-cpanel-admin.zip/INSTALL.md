# Cara Install di cPanel — Call Center Finance Forum

## Yang ada di paket ini
- **Halaman web** (homepage, forum, ojk-regulasi, edukasi, kontak, login, register) — HTML statis
- **Halaman artikel** — dibaca dinamis dari database MySQL (SEO-friendly)
- **Dashboard Admin** (`/admin/`) — tambah/edit/hapus artikel + kelola meta SEO/keyword + upload gambar
- **API PHP** — backend untuk artikel CRUD, login admin, upload gambar, sitemap
- **Sitemap otomatis** — generate dari artikel di database (auto-index Google)

## LANGKAH INSTALL

### 1. Upload & Extract
1. Login cPanel → **File Manager** → masuk `public_html`
2. Upload file zip ini → klik kanan → **Extract** ke `public_html/`
3. Pastikan struktur: `public_html/index.html`, `public_html/api/`, `public_html/admin/`, `public_html/.htaccess`

### 2. Buat Database MySQL
1. cPanel → **MySQL Databases** → Create New Database (contoh: `callcenter_db`)
2. Create User + beri password → Add User to Database → centang **ALL PRIVILEGES**
3. cPanel → **phpMyAdmin** → pilih database → tab **Import** → upload file `schema.sql`
   (atau buka tab **SQL**, copy-paste isi `schema.sql`, klik Go)

### 3. Konfigurasi Koneksi Database
1. Edit file `api/config.php` (via File Manager > Edit)
2. Ubah baris ini sesuai database kamu:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'callcenter_db');    // nama database
define('DB_USER', 'user_kamu');         // username database
define('DB_PASS', 'password_kamu');     // password database
define('SITE_URL', 'https://domainkamu.com');  // domain kamu
```

### 4. Set Permission Folder Upload
- Folder `api/uploads/` harus writable (chmod 755 atau 777 jika perlu)
- cPanel → File Manager → klik kanan `api/uploads` → Change Permissions → 755

### 5. Test
- Buka `https://domainkamu.com/` → halaman web muncul ✅
- Buka `https://domainkamu.com/admin/` → login admin
  - Default: **username** `admin` **password** `admin123`
  - **GANTI PASSWORD setelah login pertama!** (edit di phpMyAdmin > admin_users > password_hash)
- Buka `https://domainkamu.com/artikel/` → daftar artikel dari database
- Buka `https://domainkamu.com/sitemap.xml` → sitemap otomatis

### 6. Submit ke Google (auto-index)
1. Buka [Google Search Console](https://search.google.com/search-console)
2. Add property → masukkan domain kamu
3. Submit sitemap: `https://domainkamu.com/sitemap.xml`
4. Google akan otomatis index semua halaman termasuk artikel baru

## Fitur Dashboard Admin
- ✅ Tambah / Edit / Hapus artikel
- ✅ Upload gambar artikel (jpg, png, webp, gif, max 5MB)
- ✅ Atur slug (URL) — otomatis dari judul atau manual
- ✅ Kelola meta SEO: meta title, meta description, meta keywords
- ✅ Kelola keyword (chips), tags
- ✅ Canonical URL, Open Graph (Facebook/Twitter share)
- ✅ Status draft/published
- ✅ Auto-generate sitemap.xml dari artikel di database
- ✅ Statistik: total artikel, published, draft, views

## Catatan
- Login admin default `admin`/`admin123` — **WAJIB ganti** untuk keamanan
- Gambar upload disimpan di `api/uploads/`
- Sitemap update otomatis tiap artikel ditambah/dihapus
- Untuk ganti password admin: phpMyAdmin → `admin_users` → Generate hash bcrypt baru
